Array=[1,2,3,4,5];
//Method 1
Array.push(6);
console.log(Array);
Array.pop();
console.log(Array);
Array.shift();
console.log(Array);
Array.unshift(0);
console.log(Array);
Array.splice(3,2);
console.log(Array)
Array.splice(2,0,99999)
console.log(Array);
