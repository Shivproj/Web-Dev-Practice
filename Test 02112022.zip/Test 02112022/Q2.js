console.log("HI");
//Demonstrating an example with loops(for loop) - printing even numbers until 100 including 100;

let n = 100;
for(i=1;i<=n;i++)
{
 
    if(i%2==0)
    {
        console.log(i);
    }
}