let x = new Date();
console.log(x);
console.log(x.getTime());
console.log(x.getHours());
console.log(x.getMinutes());
console.log(x.getMonth());
console.log(x.getTimezoneOffset());
console.log(x.getUTCFullYear());

